AR05 synthetic fixture survey: local reversible label only.
