# full-deferred
Synthetic protocol fixture report; not an actual review of the product.
Unique run context: 2026-10-23T13:32:43.212582Z
