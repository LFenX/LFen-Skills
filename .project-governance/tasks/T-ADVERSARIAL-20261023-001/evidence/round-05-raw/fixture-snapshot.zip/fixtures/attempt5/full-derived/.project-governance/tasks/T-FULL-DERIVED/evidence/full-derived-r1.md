Synthetic report was materially changed after append.
