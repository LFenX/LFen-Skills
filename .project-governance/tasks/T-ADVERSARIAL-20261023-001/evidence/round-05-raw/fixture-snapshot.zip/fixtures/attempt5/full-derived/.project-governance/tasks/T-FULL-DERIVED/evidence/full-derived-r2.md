# full-derived-r2
Synthetic protocol fixture report; not an actual review of the product.
Unique run context: 2026-10-23T13:41:53.471525Z
