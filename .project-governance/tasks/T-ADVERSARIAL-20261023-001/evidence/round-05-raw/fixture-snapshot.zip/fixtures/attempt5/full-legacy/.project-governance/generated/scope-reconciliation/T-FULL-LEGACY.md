# Scope Reconciliation: T-FULL-LEGACY

- Status: Skipped
- Changed paths seen by Git: 0

## Declared but untouched

- none
