# Scope Reconciliation: T-FULL-OLD-PROTOCOL

- Status: Skipped
- Changed paths seen by Git: 0

## Declared but untouched

- none
