# min-dummy-before-offer
Synthetic protocol fixture report; not an actual review of the product.
Unique run context: 2026-10-23T13:32:52.361646Z
