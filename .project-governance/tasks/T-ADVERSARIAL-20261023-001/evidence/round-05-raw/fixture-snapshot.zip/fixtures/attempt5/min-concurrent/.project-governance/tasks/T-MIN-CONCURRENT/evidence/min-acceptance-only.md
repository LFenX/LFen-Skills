# min-acceptance-only
Synthetic protocol fixture report; not an actual review of the product.
Unique run context: 2026-10-23T13:38:36.460192Z
