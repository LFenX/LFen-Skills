# min-after-ended-stale
Synthetic protocol fixture report; not an actual review of the product.
Unique run context: 2026-10-23T13:35:22.421639Z
