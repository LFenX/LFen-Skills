Synthetic independent AR-06 report T-AMB-P ambiguous-round; Temp-only fixture.
