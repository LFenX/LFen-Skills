Synthetic independent AR-06 report T-AMB-P base-clean; Temp-only fixture.
