Synthetic AR-06 Temp fixture, no real human authorization.
