Synthetic independent AR-06 report T-BLOCKED-F after-stale; Temp-only fixture.
