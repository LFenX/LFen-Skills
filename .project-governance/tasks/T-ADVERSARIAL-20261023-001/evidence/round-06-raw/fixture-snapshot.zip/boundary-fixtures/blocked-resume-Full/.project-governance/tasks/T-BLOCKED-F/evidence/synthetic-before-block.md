Synthetic independent AR-06 report T-BLOCKED-F before-block; Temp-only fixture.
