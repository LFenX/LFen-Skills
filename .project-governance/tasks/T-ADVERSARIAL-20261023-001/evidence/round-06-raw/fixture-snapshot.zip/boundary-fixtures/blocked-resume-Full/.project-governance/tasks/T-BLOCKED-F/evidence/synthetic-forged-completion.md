Synthetic independent AR-06 report T-BLOCKED-F forged-completion; Temp-only fixture.
