Synthetic independent AR-06 report T-BLOCKED-F fresh-after-ended; Temp-only fixture.
