Synthetic independent AR-06 report T-BLOCKED-F no-new-decision; Temp-only fixture.
