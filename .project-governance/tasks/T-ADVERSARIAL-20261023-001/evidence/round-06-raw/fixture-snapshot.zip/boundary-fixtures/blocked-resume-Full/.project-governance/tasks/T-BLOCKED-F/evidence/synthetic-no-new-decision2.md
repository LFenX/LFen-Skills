Synthetic independent AR-06 report T-BLOCKED-F no-new-decision2; Temp-only fixture.
