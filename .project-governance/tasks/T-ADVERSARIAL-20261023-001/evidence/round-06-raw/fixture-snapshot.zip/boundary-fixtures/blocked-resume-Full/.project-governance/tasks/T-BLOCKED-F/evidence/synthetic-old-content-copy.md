Synthetic independent AR-06 report T-BLOCKED-F after-block; Temp-only fixture.
