Synthetic independent AR-06 report T-BLOCKED-M after-stale; Temp-only fixture.
