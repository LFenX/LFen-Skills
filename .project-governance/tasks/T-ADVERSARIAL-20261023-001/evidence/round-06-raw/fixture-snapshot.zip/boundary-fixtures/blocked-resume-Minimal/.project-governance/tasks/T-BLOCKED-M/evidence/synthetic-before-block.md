Synthetic independent AR-06 report T-BLOCKED-M before-block; Temp-only fixture.
