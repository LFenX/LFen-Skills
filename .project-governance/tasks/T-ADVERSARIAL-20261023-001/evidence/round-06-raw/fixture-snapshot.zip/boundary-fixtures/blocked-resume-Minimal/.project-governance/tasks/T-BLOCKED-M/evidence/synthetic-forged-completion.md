Synthetic independent AR-06 report T-BLOCKED-M forged-completion; Temp-only fixture.
