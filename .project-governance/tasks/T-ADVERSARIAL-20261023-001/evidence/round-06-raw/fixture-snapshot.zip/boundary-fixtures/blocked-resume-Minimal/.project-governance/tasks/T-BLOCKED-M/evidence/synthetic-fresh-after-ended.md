Synthetic independent AR-06 report T-BLOCKED-M fresh-after-ended; Temp-only fixture.
