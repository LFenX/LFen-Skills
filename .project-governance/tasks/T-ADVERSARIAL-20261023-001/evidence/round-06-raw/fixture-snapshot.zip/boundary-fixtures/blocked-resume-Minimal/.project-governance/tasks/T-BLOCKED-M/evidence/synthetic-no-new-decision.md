Synthetic independent AR-06 report T-BLOCKED-M no-new-decision; Temp-only fixture.
