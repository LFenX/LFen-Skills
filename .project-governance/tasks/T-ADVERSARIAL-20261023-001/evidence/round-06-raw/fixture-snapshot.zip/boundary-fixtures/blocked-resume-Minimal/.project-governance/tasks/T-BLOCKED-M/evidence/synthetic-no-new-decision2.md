Synthetic independent AR-06 report T-BLOCKED-M no-new-decision2; Temp-only fixture.
