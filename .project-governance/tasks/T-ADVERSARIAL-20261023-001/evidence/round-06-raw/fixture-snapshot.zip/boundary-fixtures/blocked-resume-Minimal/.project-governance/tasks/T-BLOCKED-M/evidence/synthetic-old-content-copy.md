Synthetic independent AR-06 report T-BLOCKED-M after-block; Temp-only fixture.
