Synthetic independent AR-06 report T-CLI-BLANK cli-round-1; Temp-only fixture.
