Synthetic independent AR-06 report T-CLI-BLANK cli-round-2; Temp-only fixture.
