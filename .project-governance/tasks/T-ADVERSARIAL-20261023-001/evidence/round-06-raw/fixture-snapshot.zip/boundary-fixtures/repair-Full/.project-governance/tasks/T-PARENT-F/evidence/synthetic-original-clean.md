Synthetic independent AR-06 report T-PARENT-F original-clean; Temp-only fixture.
