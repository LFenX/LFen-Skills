Synthetic independent AR-06 report T-PARENT-F repair-discovered; Temp-only fixture.
