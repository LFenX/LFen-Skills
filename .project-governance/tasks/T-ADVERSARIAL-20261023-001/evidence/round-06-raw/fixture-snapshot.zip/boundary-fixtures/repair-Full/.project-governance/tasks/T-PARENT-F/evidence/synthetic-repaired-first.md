Synthetic independent AR-06 report T-PARENT-F repaired-first; Temp-only fixture.
