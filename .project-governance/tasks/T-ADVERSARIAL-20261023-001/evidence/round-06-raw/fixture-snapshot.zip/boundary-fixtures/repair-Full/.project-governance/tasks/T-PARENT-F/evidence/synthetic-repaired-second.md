Synthetic independent AR-06 report T-PARENT-F repaired-second; Temp-only fixture.
