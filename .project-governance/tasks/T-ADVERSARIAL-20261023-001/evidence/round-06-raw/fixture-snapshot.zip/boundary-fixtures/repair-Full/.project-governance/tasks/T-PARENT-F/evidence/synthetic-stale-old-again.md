Synthetic independent AR-06 report T-PARENT-F stale-old-again; Temp-only fixture.
