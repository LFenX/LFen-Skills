Synthetic independent AR-06 report T-PARENT-F stale-old; Temp-only fixture.
