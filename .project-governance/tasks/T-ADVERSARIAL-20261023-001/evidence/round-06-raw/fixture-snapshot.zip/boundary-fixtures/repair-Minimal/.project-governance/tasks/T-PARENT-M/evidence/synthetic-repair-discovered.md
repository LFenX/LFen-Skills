Synthetic independent AR-06 report T-PARENT-M repair-discovered; Temp-only fixture.
