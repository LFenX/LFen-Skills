Synthetic independent AR-06 report T-PARENT-M repaired-first; Temp-only fixture.
