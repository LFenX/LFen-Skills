Synthetic independent AR-06 report T-PARENT-M repaired-second; Temp-only fixture.
