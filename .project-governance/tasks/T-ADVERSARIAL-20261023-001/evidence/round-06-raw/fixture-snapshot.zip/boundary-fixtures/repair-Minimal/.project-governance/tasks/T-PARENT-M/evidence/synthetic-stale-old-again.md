Synthetic independent AR-06 report T-PARENT-M stale-old-again; Temp-only fixture.
