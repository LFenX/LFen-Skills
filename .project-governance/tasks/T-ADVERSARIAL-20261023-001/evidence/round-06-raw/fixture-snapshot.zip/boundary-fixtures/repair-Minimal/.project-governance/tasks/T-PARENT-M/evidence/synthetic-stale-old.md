Synthetic independent AR-06 report T-PARENT-M stale-old; Temp-only fixture.
