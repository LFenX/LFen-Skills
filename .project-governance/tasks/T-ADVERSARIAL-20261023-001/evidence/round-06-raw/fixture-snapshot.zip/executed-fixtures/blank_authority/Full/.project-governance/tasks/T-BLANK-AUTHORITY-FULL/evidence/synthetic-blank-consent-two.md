Synthetic independent AR-06 report T-BLANK-AUTHORITY-FULL blank-consent-two; Temp-only fixture.
