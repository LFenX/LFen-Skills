Synthetic independent AR-06 report T-BLANK-AUTHORITY-MINIMAL blank-consent-one; Temp-only fixture.
