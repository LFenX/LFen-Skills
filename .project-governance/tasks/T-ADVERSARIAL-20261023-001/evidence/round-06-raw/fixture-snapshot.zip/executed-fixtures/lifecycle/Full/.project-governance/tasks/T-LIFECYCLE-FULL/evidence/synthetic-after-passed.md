Synthetic independent AR-06 report T-LIFECYCLE-FULL after-passed; Temp-only fixture.
