Synthetic independent AR-06 report T-LIFECYCLE-FULL after-stop; Temp-only fixture.
