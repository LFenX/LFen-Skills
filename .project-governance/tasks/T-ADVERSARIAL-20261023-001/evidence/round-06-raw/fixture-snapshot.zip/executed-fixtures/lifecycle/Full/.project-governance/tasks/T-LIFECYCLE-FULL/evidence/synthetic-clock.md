Synthetic independent AR-06 report T-LIFECYCLE-FULL clock; Temp-only fixture.
