Synthetic independent AR-06 report T-LIFECYCLE-FULL complete-one; Temp-only fixture.
