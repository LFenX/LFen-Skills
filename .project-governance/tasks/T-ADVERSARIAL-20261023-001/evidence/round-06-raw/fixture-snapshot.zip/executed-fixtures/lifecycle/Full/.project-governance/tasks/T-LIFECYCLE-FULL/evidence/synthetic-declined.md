Synthetic independent AR-06 report T-LIFECYCLE-FULL declined; Temp-only fixture.
