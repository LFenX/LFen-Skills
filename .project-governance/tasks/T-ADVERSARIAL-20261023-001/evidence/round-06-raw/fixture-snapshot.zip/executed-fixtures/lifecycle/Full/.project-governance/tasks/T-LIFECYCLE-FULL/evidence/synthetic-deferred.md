Synthetic independent AR-06 report T-LIFECYCLE-FULL deferred; Temp-only fixture.
