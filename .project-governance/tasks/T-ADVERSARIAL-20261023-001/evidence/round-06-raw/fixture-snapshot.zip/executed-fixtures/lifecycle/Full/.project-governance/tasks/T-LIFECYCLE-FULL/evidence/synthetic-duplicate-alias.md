Synthetic independent AR-06 report T-LIFECYCLE-FULL duplicate-alias; Temp-only fixture.
