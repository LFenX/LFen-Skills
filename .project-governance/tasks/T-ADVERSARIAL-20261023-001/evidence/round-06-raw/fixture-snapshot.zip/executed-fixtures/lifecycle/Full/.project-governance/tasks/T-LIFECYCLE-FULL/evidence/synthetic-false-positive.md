Synthetic independent AR-06 report T-LIFECYCLE-FULL false-positive; Temp-only fixture.
