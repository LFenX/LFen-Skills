Synthetic independent AR-06 report T-LIFECYCLE-FULL false-receipt; Temp-only fixture.
