Synthetic independent AR-06 report T-LIFECYCLE-FULL final-two; Temp-only fixture.
