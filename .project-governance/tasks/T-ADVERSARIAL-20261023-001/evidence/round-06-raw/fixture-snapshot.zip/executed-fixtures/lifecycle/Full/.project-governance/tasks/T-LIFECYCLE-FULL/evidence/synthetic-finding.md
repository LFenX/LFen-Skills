Synthetic independent AR-06 report T-LIFECYCLE-FULL finding; Temp-only fixture.
