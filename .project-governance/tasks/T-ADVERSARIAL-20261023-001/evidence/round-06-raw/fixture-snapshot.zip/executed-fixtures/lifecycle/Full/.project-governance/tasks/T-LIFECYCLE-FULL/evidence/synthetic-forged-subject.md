Synthetic independent AR-06 report T-LIFECYCLE-FULL forged-subject; Temp-only fixture.
