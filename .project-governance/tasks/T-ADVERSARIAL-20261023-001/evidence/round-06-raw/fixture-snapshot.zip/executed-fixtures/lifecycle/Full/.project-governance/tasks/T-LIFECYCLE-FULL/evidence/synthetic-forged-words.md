Synthetic independent AR-06 report T-LIFECYCLE-FULL forged-words; Temp-only fixture.
