Synthetic independent AR-06 report T-LIFECYCLE-FULL future; Temp-only fixture.
