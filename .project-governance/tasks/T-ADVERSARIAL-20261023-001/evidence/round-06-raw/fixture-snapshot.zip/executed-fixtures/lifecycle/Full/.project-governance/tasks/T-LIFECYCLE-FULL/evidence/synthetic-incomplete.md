Synthetic independent AR-06 report T-LIFECYCLE-FULL incomplete; Temp-only fixture.
