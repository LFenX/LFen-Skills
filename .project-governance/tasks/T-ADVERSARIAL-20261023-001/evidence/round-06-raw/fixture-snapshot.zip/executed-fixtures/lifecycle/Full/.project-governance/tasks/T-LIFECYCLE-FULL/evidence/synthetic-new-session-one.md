Synthetic independent AR-06 report T-LIFECYCLE-FULL new-session-one; Temp-only fixture.
