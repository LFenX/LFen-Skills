Synthetic independent AR-06 report T-LIFECYCLE-FULL no-consent; Temp-only fixture.
