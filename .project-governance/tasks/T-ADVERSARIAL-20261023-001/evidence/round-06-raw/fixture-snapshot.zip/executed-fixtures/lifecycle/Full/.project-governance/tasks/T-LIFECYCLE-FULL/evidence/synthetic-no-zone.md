Synthetic independent AR-06 report T-LIFECYCLE-FULL no-zone; Temp-only fixture.
