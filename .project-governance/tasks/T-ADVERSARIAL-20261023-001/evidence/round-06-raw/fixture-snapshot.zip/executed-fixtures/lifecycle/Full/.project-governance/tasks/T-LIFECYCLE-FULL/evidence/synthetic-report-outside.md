Synthetic independent AR-06 report T-LIFECYCLE-FULL report-outside; Temp-only fixture.
