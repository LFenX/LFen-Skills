Synthetic independent AR-06 report T-LIFECYCLE-FULL same-fix; Temp-only fixture.
