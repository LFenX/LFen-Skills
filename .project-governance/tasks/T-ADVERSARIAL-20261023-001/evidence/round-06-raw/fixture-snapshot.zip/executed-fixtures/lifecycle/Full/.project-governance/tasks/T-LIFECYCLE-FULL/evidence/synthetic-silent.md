Synthetic independent AR-06 report T-LIFECYCLE-FULL silent; Temp-only fixture.
