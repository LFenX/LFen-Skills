Synthetic independent AR-06 report T-LIFECYCLE-FULL unresolved; Temp-only fixture.
