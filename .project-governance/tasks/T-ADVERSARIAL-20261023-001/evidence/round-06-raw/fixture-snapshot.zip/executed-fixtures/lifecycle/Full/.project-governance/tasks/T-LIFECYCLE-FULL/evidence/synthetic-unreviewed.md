Synthetic independent AR-06 report T-LIFECYCLE-FULL unreviewed; Temp-only fixture.
