Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL after-passed; Temp-only fixture.
