Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL after-stop; Temp-only fixture.
