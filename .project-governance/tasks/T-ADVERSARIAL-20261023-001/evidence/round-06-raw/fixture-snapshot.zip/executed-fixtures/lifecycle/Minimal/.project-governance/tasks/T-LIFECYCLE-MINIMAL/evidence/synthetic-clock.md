Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL clock; Temp-only fixture.
