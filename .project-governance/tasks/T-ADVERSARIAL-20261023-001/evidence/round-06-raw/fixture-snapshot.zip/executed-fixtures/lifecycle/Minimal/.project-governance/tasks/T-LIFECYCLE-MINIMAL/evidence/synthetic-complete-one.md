Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL complete-one; Temp-only fixture.
