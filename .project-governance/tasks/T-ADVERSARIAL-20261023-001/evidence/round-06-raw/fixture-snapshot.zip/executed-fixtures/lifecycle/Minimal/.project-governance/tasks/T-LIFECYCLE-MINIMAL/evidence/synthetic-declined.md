Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL declined; Temp-only fixture.
