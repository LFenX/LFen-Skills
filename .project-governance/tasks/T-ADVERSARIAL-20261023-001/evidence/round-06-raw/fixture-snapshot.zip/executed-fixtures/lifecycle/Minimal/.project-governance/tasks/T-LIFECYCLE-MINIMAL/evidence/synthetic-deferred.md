Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL deferred; Temp-only fixture.
