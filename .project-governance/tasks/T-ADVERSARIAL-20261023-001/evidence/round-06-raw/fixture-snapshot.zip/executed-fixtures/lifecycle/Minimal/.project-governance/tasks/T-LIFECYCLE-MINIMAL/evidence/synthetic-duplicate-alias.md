Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL duplicate-alias; Temp-only fixture.
