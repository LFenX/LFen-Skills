Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL false-positive; Temp-only fixture.
