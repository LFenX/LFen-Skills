Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL false-receipt; Temp-only fixture.
