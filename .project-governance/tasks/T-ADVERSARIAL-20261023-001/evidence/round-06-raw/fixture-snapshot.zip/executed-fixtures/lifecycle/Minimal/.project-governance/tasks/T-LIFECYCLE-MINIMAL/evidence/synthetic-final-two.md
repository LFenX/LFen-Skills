Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL final-two; Temp-only fixture.
