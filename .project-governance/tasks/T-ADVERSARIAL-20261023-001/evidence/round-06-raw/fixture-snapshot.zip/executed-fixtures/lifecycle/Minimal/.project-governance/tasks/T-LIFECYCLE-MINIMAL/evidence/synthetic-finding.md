Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL finding; Temp-only fixture.
