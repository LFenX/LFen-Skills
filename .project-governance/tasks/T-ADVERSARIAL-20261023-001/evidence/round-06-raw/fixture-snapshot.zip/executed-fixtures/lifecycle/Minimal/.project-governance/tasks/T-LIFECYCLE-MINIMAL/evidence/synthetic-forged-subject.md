Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL forged-subject; Temp-only fixture.
