Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL forged-words; Temp-only fixture.
