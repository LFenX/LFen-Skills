Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL future; Temp-only fixture.
