Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL new-session-one; Temp-only fixture.
