Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL no-consent; Temp-only fixture.
