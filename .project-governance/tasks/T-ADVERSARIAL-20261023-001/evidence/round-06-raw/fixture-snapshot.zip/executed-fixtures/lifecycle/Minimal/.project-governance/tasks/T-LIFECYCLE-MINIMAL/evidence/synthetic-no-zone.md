Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL no-zone; Temp-only fixture.
