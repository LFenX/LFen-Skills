Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL same-fix; Temp-only fixture.
