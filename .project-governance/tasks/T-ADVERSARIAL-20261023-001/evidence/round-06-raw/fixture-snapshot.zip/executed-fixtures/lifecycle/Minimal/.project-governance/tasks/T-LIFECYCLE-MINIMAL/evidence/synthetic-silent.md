Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL silent; Temp-only fixture.
