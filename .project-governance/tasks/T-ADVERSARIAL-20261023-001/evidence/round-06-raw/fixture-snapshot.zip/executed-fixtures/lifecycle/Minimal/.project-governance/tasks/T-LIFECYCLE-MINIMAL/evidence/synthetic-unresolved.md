Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL unresolved; Temp-only fixture.
