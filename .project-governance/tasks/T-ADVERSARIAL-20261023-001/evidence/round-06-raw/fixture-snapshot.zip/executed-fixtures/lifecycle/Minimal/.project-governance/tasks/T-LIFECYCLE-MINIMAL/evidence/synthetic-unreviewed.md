Synthetic independent AR-06 report T-LIFECYCLE-MINIMAL unreviewed; Temp-only fixture.
