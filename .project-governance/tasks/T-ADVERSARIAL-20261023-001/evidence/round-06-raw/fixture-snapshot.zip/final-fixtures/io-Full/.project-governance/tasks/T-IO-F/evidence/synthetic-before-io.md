Synthetic independent AR-06 report T-IO-F before-io; Temp-only fixture.
