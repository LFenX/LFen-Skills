Synthetic independent AR-06 report T-IO-F io-retry; Temp-only fixture.
