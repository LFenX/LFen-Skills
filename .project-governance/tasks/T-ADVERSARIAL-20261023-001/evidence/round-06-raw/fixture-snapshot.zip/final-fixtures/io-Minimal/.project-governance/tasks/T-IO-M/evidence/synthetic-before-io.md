Synthetic independent AR-06 report T-IO-M before-io; Temp-only fixture.
