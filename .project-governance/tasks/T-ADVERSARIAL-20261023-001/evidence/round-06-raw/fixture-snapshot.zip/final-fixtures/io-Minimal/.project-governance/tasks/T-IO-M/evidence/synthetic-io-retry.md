Synthetic independent AR-06 report T-IO-M io-retry; Temp-only fixture.
